i_view32.exe /slideshow=. /reloadonloop /filepattern="*.png;*.jpg;*.gif"
